public class Q123 {
    
}
